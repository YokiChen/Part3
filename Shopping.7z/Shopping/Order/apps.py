from django.apps import AppConfig


class OrderConfig(AppConfig):
    name = 'Order'
